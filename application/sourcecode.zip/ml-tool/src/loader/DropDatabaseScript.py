from src.loader.database.MongoDBConnector import MongoDBConnector

db = MongoDBConnector()
db.reset_data()
